package com.example.blood_donation_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
